from __future__ import annotations
import csv, io, json, os, sys, webbrowser, threading, shutil
from collections import defaultdict
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from dhappa import model_v2_5 as core
from dhappa_logging import log as audit_log, log_exception, sha256_file

DATA_PATH = ROOT / 'data' / 'Merged_Workbook.csv'
BACKUP_DIR = ROOT / 'data' / 'backups'
METRICS_PATH = ROOT / 'reports' / 'single_engine_performance.json'
CONS_METRICS_PATH = ROOT / 'reports' / 'consensus36_performance.json'
CONS_WEIGHTS_PATH = ROOT / 'reports' / 'consensus36_weights.json'
DATA_LOCK = threading.RLock()

CONS_WEIGHTS_DEFAULT={
 'DATE_TRIAD':1.50,'PREVIOUS_DAY':1.10,'DELTA_MATRIX':0.90,'G_SQUARE':1.00,
 'G_SQUARE_HARMONICS':1.00,'HARUF_PYRAMID':1.20,'LOOKBACK_5':1.00,'ECHO_7':0.80,
 'HOT_RECENCY':0.70,'RASHI_FAMILY':0.90,'TRANSITION_MARKOV':1.20,'MODEL_F':1.30,
}

def _load_json(path, default):
    try: return json.load(open(path, encoding='utf-8')) if path.exists() else default
    except Exception: return default

ROWS = core.load_csv(DATA_PATH)
METRICS = _load_json(METRICS_PATH,{})
CONS_METRICS = _load_json(CONS_METRICS_PATH,{})
CONS_WEIGHTS = _load_json(CONS_WEIGHTS_PATH,CONS_WEIGHTS_DEFAULT)
ENGINE_MAP = {e.name: e for e in core.ENGINES}
ENGINE_ORDER = [e.name for e in core.ENGINES]
ENGINE_FAMILY = {e.name: e.family for e in core.ENGINES}
ENGINE_DESCRIPTIONS = {
    'DATE_TRIAD':'Calendar/date-derived anchors with reverse and mirror extensions.',
    'PREVIOUS_DAY':'Previous-house-result transformations and digit arithmetic.',
    'DELTA_MATRIX':'Two-step digit delta propagation and transformed variants.',
    'G_SQUARE':'G-Square digit field derived from the latest house result.',
    'G_SQUARE_HARMONICS':'Expanded harmonic digit field around the G-Square source.',
    'HARUF_PYRAMID':'Recent digit-frequency Haruf layers and pyramid transforms.',
    'LOOKBACK_5':'Five-draw recency, palti/mirror and root-family reinforcement.',
    'ECHO_7':'7/14/21-lag echo recurrence with palti and mirror support.',
    'HOT_RECENCY':'Decay-weighted historical frequency plus bounded gap bonus.',
    'RASHI_FAMILY':'Root-family concentration with recent reverse/mirror support.',
    'TRANSITION_MARKOV':'Observed pair/digit transitions from the latest house state.',
    'MODEL_F':'Composite rank fusion across selected core engines.'
}

ALIASES={
 'date':'Date','drawdate':'Date','draw_date':'Date',
 'deshawar':'Deshawar','ds':'Deshawar','dswr':'Deshawar',
 'faridabad':'Faridabad','fb':'Faridabad','frbd':'Faridabad',
 'ghaziabad':'Ghaziabad','gb':'Ghaziabad','gzbd':'Ghaziabad',
 'gali':'Gali','gl':'Gali',
}

def consensus36(rankings_by_engine):
    score=defaultdict(float); supporters=defaultdict(list); contribution=defaultdict(dict)
    for eng_name, ranking in rankings_by_engine.items():
        top=ranking[:36]; n=max(1,len(top)); w=float(CONS_WEIGHTS.get(eng_name,1.0))
        for idx,cand in enumerate(top):
            c=w*((n-idx)/n); score[cand]+=c; supporters[cand].append(eng_name); contribution[cand][eng_name]=round(c,6)
    ranked=sorted([f'{i:02d}' for i in range(100)],key=lambda c:(-score[c],-len(supporters[c]),c))
    details=[{'rank':i+1,'number':c,'score':round(score[c],6),'support_count':len(supporters[c]),'engines':supporters[c],'contributions':contribution[c]} for i,c in enumerate(ranked[:36])]
    return ranked,details

def metric(events):
    if not events:return {'n':0,'h5':0,'h10':0,'h21':0,'h36':0,'mrr':0,'median_rank':101,'mean_rank':101}
    ranks=sorted(e['rank'] for e in events); n=len(ranks)
    med=ranks[n//2] if n%2 else (ranks[n//2-1]+ranks[n//2])/2
    return {'n':n,'h5':sum(r<=5 for r in ranks)/n,'h10':sum(r<=10 for r in ranks)/n,'h21':sum(r<=21 for r in ranks)/n,'h36':sum(r<=36 for r in ranks)/n,'mrr':sum(1/r for r in ranks)/n,'median_rank':med,'mean_rank':sum(ranks)/n}

def windows(events):
    out={str(w):metric(events[-w:]) for w in (15,30,60)}; out['expanding']=metric(events); return out

def rebuild_metrics():
    global METRICS,CONS_METRICS
    started=datetime.utcnow().isoformat()+'Z'
    audit_log('metrics','rebuild_start',row_count=len(ROWS),engine_count=len(ENGINE_ORDER),houses=list(core.HOUSES))
    eng_events={h:{n:[] for n in ENGINE_ORDER} for h in core.HOUSES}; cons_events={h:[] for h in core.HOUSES}
    # Need a small warm-up so recency/transition engines have meaningful history.
    for i in range(15,len(ROWS)):
        hist=ROWS[:i]; target=ROWS[i]; td=target['date']
        by_house={h:{} for h in core.HOUSES}
        for n in ENGINE_ORDER:
            eng=ENGINE_MAP[n]
            for h in core.HOUSES:
                out=eng.rank(hist,h,td); by_house[h][n]=out.ranking
                actual=target.get(h)
                if actual: eng_events[h][n].append({'date':td,'rank':out.ranking.index(actual)+1})
        for h in core.HOUSES:
            actual=target.get(h)
            if actual:
                ranked,_=consensus36(by_house[h]); cons_events[h].append({'date':td,'rank':ranked.index(actual)+1})
    METRICS={h:{n:windows(eng_events[h][n]) for n in ENGINE_ORDER} for h in core.HOUSES}
    CONS_METRICS={h:windows(cons_events[h]) for h in core.HOUSES}
    ROOT.joinpath('reports').mkdir(exist_ok=True)
    METRICS_PATH.write_text(json.dumps(METRICS,indent=2),encoding='utf-8')
    CONS_METRICS_PATH.write_text(json.dumps(CONS_METRICS,indent=2),encoding='utf-8')
    CONS_WEIGHTS_PATH.write_text(json.dumps(CONS_WEIGHTS,indent=2),encoding='utf-8')
    audit_log('metrics','rebuild_complete',started_utc=started,row_count=len(ROWS),engine_count=len(ENGINE_ORDER),houses=list(core.HOUSES),metrics_path=str(METRICS_PATH),consensus_metrics_path=str(CONS_METRICS_PATH))

def strict_number(v, field):
    if v is None:return None
    s=str(v).strip()
    if not s or s.lower() in {'nan','none','xx','x','-','na','n/a'}: return None
    try:
        x=int(float(s))
        if 0<=x<=99:return f'{x:02d}'
    except: pass
    raise ValueError(f'{field}: invalid value {v!r}; expected 00-99 or blank')

def canonical_header(name):
    key=str(name).strip().lower().replace(' ','').replace('-','_')
    return ALIASES.get(key)

def parse_import_text(text, has_header=True):
    text=(text or '').replace('\ufeff','').strip()
    if not text:return [],['No data supplied']
    errors=[]; parsed=[]
    if has_header:
        reader=csv.DictReader(io.StringIO(text))
        if not reader.fieldnames:return [],['CSV header is missing']
        colmap={f:canonical_header(f) for f in reader.fieldnames}
        if 'Date' not in colmap.values():return [],['Missing Date column']
        for line_no,r in enumerate(reader,start=2):
            try:
                normalized={}
                for src,val in r.items():
                    dst=colmap.get(src)
                    if dst: normalized[dst]=val
                d=core.parse_date(str(normalized.get('Date','')).strip()).strftime('%Y-%m-%d')
                row={'date':d}
                for h in core.HOUSES: row[h]=strict_number(normalized.get(h,''),h)
                if not any(row[h] for h in core.HOUSES): raise ValueError('all four house values are blank')
                parsed.append(row)
            except Exception as e: errors.append(f'Line {line_no}: {e}')
    else:
        for line_no,line in enumerate(text.splitlines(),start=1):
            if not line.strip():continue
            try:
                parts=[x.strip() for x in next(csv.reader([line]))]
                if len(parts)!=5: raise ValueError('expected 5 fields: Date, Deshawar, Faridabad, Ghaziabad, Gali')
                d=core.parse_date(parts[0]).strftime('%Y-%m-%d')
                row={'date':d,'Deshawar':strict_number(parts[1],'Deshawar'),'Faridabad':strict_number(parts[2],'Faridabad'),'Ghaziabad':strict_number(parts[3],'Ghaziabad'),'Gali':strict_number(parts[4],'Gali')}
                if not any(row[h] for h in core.HOUSES): raise ValueError('all four house values are blank')
                parsed.append(row)
            except Exception as e:errors.append(f'Line {line_no}: {e}')
    # Merge duplicate dates within import, later nonblank values win.
    merged={}
    for r in parsed:
        if r['date'] not in merged:merged[r['date']]=r.copy()
        else:
            for h in core.HOUSES:
                if r[h] is not None:merged[r['date']][h]=r[h]
    return [merged[k] for k in sorted(merged)],errors

def import_preview(text, has_header=True):
    rows,errors=parse_import_text(text,has_header)
    existing={r['date']:r for r in ROWS}
    duplicate=sum(1 for r in rows if r['date'] in existing)
    new=sum(1 for r in rows if r['date'] not in existing)
    changes=0
    for r in rows:
        old=existing.get(r['date'])
        if old and any(r[h] is not None and r[h]!=old.get(h) for h in core.HOUSES):changes+=1
    result={'valid_rows':len(rows),'error_count':len(errors),'errors':errors[:100],'new_dates':new,'duplicate_dates':duplicate,'dates_with_changes':changes,'first_date':rows[0]['date'] if rows else None,'last_date':rows[-1]['date'] if rows else None,'sample':rows[:8]}
    audit_log('imports','preview',has_header=has_header,valid_rows=result['valid_rows'],error_count=result['error_count'],new_dates=new,duplicate_dates=duplicate,dates_with_changes=changes,first_date=result['first_date'],last_date=result['last_date'],payload_bytes=len((text or '').encode('utf-8')))
    return result

def save_rows(rows):
    DATA_PATH.parent.mkdir(exist_ok=True); BACKUP_DIR.mkdir(parents=True,exist_ok=True)
    if DATA_PATH.exists():
        stamp=datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_path=BACKUP_DIR/f'Merged_Workbook_before_{stamp}.csv'
        shutil.copy2(DATA_PATH,backup_path)
        audit_log('changes','data_backup_created',path=str(backup_path),sha256=sha256_file(backup_path),bytes=backup_path.stat().st_size)
    tmp=DATA_PATH.with_suffix('.csv.tmp')
    with open(tmp,'w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['Date','Deshawar','Faridabad','Gali','Ghaziabad']);w.writeheader()
        for r in rows:w.writerow({'Date':r['date'],'Deshawar':r.get('Deshawar') or '','Faridabad':r.get('Faridabad') or '','Gali':r.get('Gali') or '','Ghaziabad':r.get('Ghaziabad') or ''})
    os.replace(tmp,DATA_PATH)
    audit_log('changes','dataset_saved',path=str(DATA_PATH),rows=len(rows),sha256=sha256_file(DATA_PATH),bytes=DATA_PATH.stat().st_size)

def commit_import(text, has_header=True, strategy='merge'):
    global ROWS
    incoming,errors=parse_import_text(text,has_header)
    if errors: raise ValueError('Import rejected; fix validation errors first: '+errors[0])
    if not incoming: raise ValueError('No valid rows to import')
    with DATA_LOCK:
        before_count=len(ROWS)
        before_last=ROWS[-1]['date'] if ROWS else None
        if strategy=='replace': final=incoming
        else:
            merged={r['date']:r.copy() for r in ROWS}
            for r in incoming:
                if r['date'] not in merged:merged[r['date']]=r.copy()
                else:
                    for h in core.HOUSES:
                        if r[h] is not None:merged[r['date']][h]=r[h]
            final=[merged[k] for k in sorted(merged)]
        save_rows(final); ROWS=core.load_csv(DATA_PATH); rebuild_metrics()
    result={'ok':True,'rows_after_import':len(ROWS),'first_date':ROWS[0]['date'],'last_date':ROWS[-1]['date'],'strategy':strategy,'metrics_rebuilt':True}
    audit_log('imports','commit',strategy=strategy,has_header=has_header,incoming_rows=len(incoming),rows_before=before_count,rows_after=len(ROWS),last_date_before=before_last,last_date_after=result['last_date'],dataset_sha256=sha256_file(DATA_PATH))
    return result

HTML = r'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>DHAPPA — Engine Lab</title>
<style>
:root{--bg:#0b1020;--panel:#121a2f;--panel2:#18223b;--text:#eef3ff;--muted:#9eacc9;--line:#293657;--good:#82e6ad;--warn:#ffd27d;--bad:#ff9a9a;--accent:#8fb6ff;--pool:#7557d6;--import:#0b6f76}*{box-sizing:border-box}body{margin:0;background:linear-gradient(180deg,#090e1a,#0d1426);color:var(--text);font-family:Inter,Segoe UI,Arial,sans-serif}header{position:sticky;top:0;z-index:10;background:rgba(9,14,26,.95);backdrop-filter:blur(12px);border-bottom:1px solid var(--line);padding:18px 22px}h1{font-size:22px;margin:0 0 5px}.sub{color:var(--muted);font-size:13px}.controls{display:flex;gap:12px;align-items:center;margin-top:12px;flex-wrap:wrap}select,button,input,textarea{background:#151e35;color:var(--text);border:1px solid #354464;border-radius:9px;padding:9px 11px}button{cursor:pointer}.wrap{padding:16px 22px 36px;max-width:1700px;margin:auto}.tabs{display:flex;gap:7px;overflow:auto;padding:3px 0 12px;position:sticky;top:105px;background:#0d1426;z-index:8}.tab{white-space:nowrap;font-size:12px}.tab.active{background:#27416e;border-color:#567cc0}.tab.pool{border-color:#6f59be}.tab.pool.active{background:#493582}.tab.import{border-color:#2a9ea6}.tab.import.active{background:#125c63}.hero{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;padding:16px;background:var(--panel);border:1px solid var(--line);border-radius:14px;margin-bottom:14px}.hero.poolhero{border-color:#5d4a9d;background:linear-gradient(135deg,#181a39,#151d34)}.hero.importhero{border-color:#247e86;background:linear-gradient(135deg,#12343a,#151d34)}.hero h2{margin:0 0 6px;font-size:20px}.pill{display:inline-block;padding:4px 8px;border-radius:999px;background:#263554;color:#cfe0ff;font-size:12px}.poolpill{background:#493582;color:#efeaff}.importpill{background:#125c63;color:#d9ffff}.desc{color:var(--muted);max-width:900px;font-size:13px}.grid{display:grid;grid-template-columns:repeat(4,minmax(260px,1fr));gap:12px}@media(max-width:1200px){.grid{grid-template-columns:repeat(2,1fr)}}@media(max-width:700px){.grid{grid-template-columns:1fr}}.card{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:14px;min-width:0}.card h3{margin:0 0 10px;font-size:15px}.nums{display:flex;flex-wrap:wrap;gap:6px}.num{min-width:32px;text-align:center;padding:6px 7px;border-radius:7px;background:#1f2c48;font-weight:650;font-size:12px}.num.top5{background:#355d48}.num.actual{outline:2px solid #ffd27d}.num.poolnum{background:#2c2552}.section{margin-top:10px}.label{color:var(--muted);font-size:11px;margin-bottom:6px}.actualrow{margin:10px 0;padding:8px;background:#10172a;border-radius:9px;font-size:12px}.good{color:var(--good)}.warn{color:var(--warn)}.bad{color:var(--bad)}table{width:100%;border-collapse:collapse;font-size:11px}th,td{text-align:right;padding:5px;border-bottom:1px solid #26324e}th:first-child,td:first-child{text-align:left}.meta{font-size:11px;color:var(--muted);word-break:break-word;margin-top:8px}.foot{color:var(--muted);font-size:11px;margin-top:15px}.pooltable{max-height:330px;overflow:auto;border:1px solid #283555;border-radius:9px}.pooltable table{min-width:620px}.pooltable td.eng{text-align:left;white-space:normal}.rankbadge{font-weight:700;color:#d9cbff}.importgrid{display:grid;grid-template-columns:1.2fr 1fr;gap:14px}@media(max-width:900px){.importgrid{grid-template-columns:1fr}}.importbox{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:16px}.importbox h3{margin-top:0}.wide{width:100%}textarea{width:100%;min-height:150px;font-family:ui-monospace,Consolas,monospace;font-size:12px;resize:vertical}.rowform{display:grid;grid-template-columns:1.3fr repeat(4,1fr);gap:8px}.actionrow{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:10px}.preview{margin-top:12px;padding:10px;border:1px solid var(--line);border-radius:9px;background:#10172a;white-space:pre-wrap;font-size:12px}.filedrop{display:block;border:1px dashed #4b6388;border-radius:10px;padding:14px;text-align:center}.mutedbox{background:#10172a;padding:10px;border-radius:9px;color:var(--muted);font-size:12px}
</style></head><body>
<header><h1>DHAPPA — 12 Engine Lab + 36 Consensus Pool + Data Import</h1><div class="sub">Individual engines · consensus pool · CSV bulk import · line-item entry · validation & backups</div><div class="controls" id="evalControls"><label>Evaluation date <select id="date"></select></label><button onclick="loadEval()">Refresh</button><span id="status" class="sub"></span></div></header>
<div class="wrap"><div id="tabs" class="tabs"></div><div id="content"></div></div>
<script>
let state=null, active='CONSENSUS_36', tabsMeta=[], importText=''; const pct=x=>(100*x).toFixed(2)+'%'; const fmt=x=>(x??0).toFixed(4);
async function api(path,opt){let r=await fetch(path,opt);let j=await r.json();if(!r.ok)throw new Error(j.error||'Request failed');return j}
async function init(){await refreshMeta();active='CONSENSUS_36';renderTabs();await loadEval()}
async function refreshMeta(){const meta=await api('/api/meta');const d=document.getElementById('date');let old=d.value;d.innerHTML='';meta.dates.slice().reverse().forEach(x=>{let o=document.createElement('option');o.value=x;o.textContent=x;d.appendChild(o)});let o=document.createElement('option');o.value='NEXT';o.textContent='NEXT TARGET (latest history + 1 day)';d.insertBefore(o,d.firstChild);d.value=(old&&[...d.options].some(x=>x.value===old))?old:'NEXT';tabsMeta=[{name:'DATA_IMPORT',family:'data'},{name:'CONSENSUS_36',family:'ensemble'},...meta.engines];window.meta=meta}
function renderTabs(){let t=document.getElementById('tabs');t.innerHTML='';tabsMeta.forEach(e=>{let b=document.createElement('button');b.className='tab '+(e.name==='CONSENSUS_36'?'pool ':'')+(e.name==='DATA_IMPORT'?'import ':'')+(e.name===active?'active':'');b.textContent=e.name==='CONSENSUS_36'?'36 CONSENSUS POOL':e.name==='DATA_IMPORT'?'BULK DATA IMPORT':e.name;b.onclick=()=>{active=e.name;renderTabs();render()};t.appendChild(b)})}
async function loadEval(){if(active==='DATA_IMPORT'){renderImport();return}document.getElementById('status').textContent='Loading…';let q=document.getElementById('date').value;state=await api('/api/evaluate?date='+encodeURIComponent(q));document.getElementById('status').textContent='Source cutoff: '+state.source_cutoff+' · target: '+state.target_date;render()}
function block(label,arr,actual,pool=false){return `<div class="section"><div class="label">${label}</div><div class="nums">${arr.map((n,i)=>`<span class="num ${i<5?'top5':''} ${n===actual?'actual':''} ${pool?'poolnum':''}">${n}</span>`).join('')}</div></div>`}
function metricsTable(m){if(!m)return '<div class="meta">No historical profile available.</div>';let rows=['15','30','60','expanding'].map(w=>{let x=m[w];return `<tr><td>${w}</td><td>${x.n}</td><td>${pct(x.h5)}</td><td>${pct(x.h10)}</td><td>${pct(x.h21)}</td><td>${pct(x.h36)}</td><td>${fmt(x.mrr)}</td><td>${Number(x.mean_rank).toFixed(1)}</td></tr>`}).join('');return `<table><thead><tr><th>Window</th><th>N</th><th>H@5</th><th>H@10</th><th>H@21</th><th>H@36</th><th>MRR</th><th>Mean Rank</th></tr></thead><tbody>${rows}</tbody></table>`}
function consensusDetailTable(details){return `<div class="pooltable"><table><thead><tr><th>Rank</th><th>Number</th><th>Score</th><th>Support</th><th style="text-align:left">Contributing engines</th></tr></thead><tbody>${details.map(d=>`<tr><td><span class="rankbadge">${d.rank}</span></td><td>${d.number}</td><td>${d.score.toFixed(3)}</td><td>${d.support_count}/12</td><td class="eng">${d.engines.join(', ')||'—'}</td></tr>`).join('')}</tbody></table></div>`}
function renderConsensus(){let c=state.consensus;let cards=Object.entries(c.houses).map(([h,x])=>{let actual=x.actual;let ar=actual?`Actual <b>${actual}</b> · consensus rank <b>${x.actual_rank}</b> · <span class="${x.actual_rank<=5?'good':x.actual_rank<=36?'warn':'bad'}">${x.actual_rank<=5?'TOP-5 HIT':x.actual_rank<=10?'TOP-10':x.actual_rank<=21?'TOP-21':x.actual_rank<=36?'TOP-36':'OUTSIDE TOP-36'}</span>`:'Forward target · outcome not available';return `<div class="card"><h3>${h}</h3><div class="actualrow">${ar}</div>${block('Top 5',x.ranking.slice(0,5),actual,true)}${block('Ranks 6–10',x.ranking.slice(5,10),actual,true)}${block('Ranks 11–21',x.ranking.slice(10,21),actual,true)}${block('Ranks 22–36',x.ranking.slice(21,36),actual,true)}<div class="section"><div class="label">Historical 36 Consensus performance</div>${metricsTable(x.metrics)}</div><div class="section"><div class="label">Top-36 candidate evidence</div>${consensusDetailTable(x.details)}</div></div>`}).join('');document.getElementById('content').innerHTML=`<div class="hero poolhero"><div><h2>36 CONSENSUS POOL</h2><span class="pill poolpill">WEIGHTED BORDA · CURRENT 12 ENGINE REGISTRY</span><p class="desc">Each engine contributes its frozen Top-36. Imported data immediately feeds this tab after validation and metrics rebuild.</p></div></div><div class="grid">${cards}</div>`}
function renderEngine(){let e=state.engines.find(x=>x.name===active);if(!e)return;let cards=Object.entries(e.houses).map(([h,x])=>{let actual=x.actual;let ar=actual?`Actual <b>${actual}</b> · rank <b>${x.actual_rank}</b>`:'Forward target · outcome not available';return `<div class="card"><h3>${h}</h3><div class="actualrow">${ar}</div>${block('Top 5',x.ranking.slice(0,5),actual)}${block('Ranks 6–10',x.ranking.slice(5,10),actual)}${block('Ranks 11–21',x.ranking.slice(10,21),actual)}${block('Ranks 22–36',x.ranking.slice(21,36),actual)}<div class="section"><div class="label">Historical performance</div>${metricsTable(x.metrics)}</div><div class="meta">Engine meta: ${JSON.stringify(x.meta)}</div></div>`}).join('');document.getElementById('content').innerHTML=`<div class="hero"><div><h2>${e.name}</h2><span class="pill">${e.family}</span><p class="desc">${e.description}</p></div></div><div class="grid">${cards}</div>`}
function renderImport(){document.getElementById('status').textContent=`Dataset: ${window.meta?.row_count||0} rows · ${window.meta?.first_date||''} to ${window.meta?.last_date||''}`;document.getElementById('content').innerHTML=`<div class="hero importhero"><div><h2>Bulk Data Import</h2><span class="pill importpill">CSV + PASTE + SINGLE LINE</span><p class="desc">Import historical draw data safely. Every commit creates a timestamped backup, validates dates and 00–99 values, merges duplicate dates deterministically, reloads all 12 engines, and rebuilds engine + 36 Consensus metrics.</p></div></div><div class="importgrid"><div class="importbox"><h3>1. CSV file upload</h3><label class="filedrop">Choose CSV<input id="csvFile" type="file" accept=".csv,text/csv" style="display:block;margin:10px auto 0" onchange="readCsv(this)"></label><div class="mutedbox" style="margin-top:10px">Supported headers: Date, Deshawar/DS, Faridabad/FB, Ghaziabad/GB, Gali/GL. Column order does not matter. Values must be 00–99 or blank.</div><div class="actionrow"><select id="strategy"><option value="merge">MERGE with current data</option><option value="replace">REPLACE current data</option></select><button onclick="previewCsv()">Preview & Validate</button><button onclick="commitCsv()">Import CSV</button></div><div id="csvPreview" class="preview">No file loaded.</div></div><div class="importbox"><h3>2. Paste multiple line items</h3><textarea id="lines" placeholder="One row per line, no header:\n2026-09-20,35,21,07,86\n2026-09-21,42,18,55,09\n\nOrder: Date, Deshawar, Faridabad, Ghaziabad, Gali"></textarea><div class="actionrow"><button onclick="previewLines()">Preview Lines</button><button onclick="commitLines()">Import Lines</button></div><div id="linePreview" class="preview">Ready for line-wise bulk paste.</div></div><div class="importbox"><h3>3. Single row entry</h3><div class="rowform"><input id="rDate" placeholder="YYYY-MM-DD"><input id="rDS" placeholder="DS"><input id="rFB" placeholder="FB"><input id="rGB" placeholder="GB"><input id="rGL" placeholder="GL"></div><div class="actionrow"><button onclick="commitSingle()">Add / Update Row</button></div><div id="singlePreview" class="preview">Duplicate date: nonblank values update that date; other existing house values are preserved.</div></div><div class="importbox"><h3>Import behavior</h3><div class="mutedbox">• MERGE is default and safest.<br>• Duplicate dates are merged; later nonblank imported values win.<br>• Invalid rows reject the entire commit—no partial silent import.<br>• Blank/XX/NA house cells are treated as missing.<br>• A backup is written under <b>data/backups/</b> before every commit.<br>• Engine and consensus historical metrics rebuild after import.<br>• Current normalized dataset can be exported anytime.</div><div class="actionrow"><button onclick="window.location='/api/data.csv'">Download Current CSV</button><button onclick="refreshMeta().then(()=>{renderTabs();renderImport()})">Refresh Dataset Status</button></div></div></div>`}
async function readCsv(el){let f=el.files[0];if(!f)return;importText=await f.text();document.getElementById('csvPreview').textContent=`Loaded ${f.name} · ${(f.size/1024).toFixed(1)} KB`;}
function showPreview(id,p){document.getElementById(id).textContent=`Valid rows: ${p.valid_rows}\nErrors: ${p.error_count}\nNew dates: ${p.new_dates}\nDuplicate dates: ${p.duplicate_dates}\nDates with changed values: ${p.dates_with_changes}\nRange: ${p.first_date||'—'} → ${p.last_date||'—'}\n${p.errors.length?'\nErrors:\n'+p.errors.join('\n'):''}`}
async function previewCsv(){try{showPreview('csvPreview',await api('/api/import/preview',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:importText,has_header:true})}))}catch(e){document.getElementById('csvPreview').textContent=e.message}}
async function commitCsv(){if(!importText)return alert('Choose a CSV first');if(!confirm('Commit this CSV import? A backup will be created.'))return;let el=document.getElementById('csvPreview');el.textContent='Importing and rebuilding metrics…';try{let r=await api('/api/import/commit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:importText,has_header:true,strategy:document.getElementById('strategy').value})});el.textContent=`SUCCESS\nRows: ${r.rows_after_import}\nRange: ${r.first_date} → ${r.last_date}\nMetrics rebuilt: ${r.metrics_rebuilt}`;await refreshMeta()}catch(e){el.textContent='FAILED: '+e.message}}
async function previewLines(){let text=document.getElementById('lines').value;try{showPreview('linePreview',await api('/api/import/preview',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text,has_header:false})}))}catch(e){document.getElementById('linePreview').textContent=e.message}}
async function commitLines(){let text=document.getElementById('lines').value;if(!text.trim())return alert('Paste one or more rows first');let el=document.getElementById('linePreview');el.textContent='Importing and rebuilding metrics…';try{let r=await api('/api/import/commit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text,has_header:false,strategy:'merge'})});el.textContent=`SUCCESS · ${r.rows_after_import} total rows · through ${r.last_date}`;await refreshMeta()}catch(e){el.textContent='FAILED: '+e.message}}
async function commitSingle(){let vals=['rDate','rDS','rFB','rGB','rGL'].map(id=>document.getElementById(id).value.trim());let text=vals.map((v,i)=>i?v:v).join(',');let el=document.getElementById('singlePreview');el.textContent='Saving and rebuilding metrics…';try{let r=await api('/api/import/commit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text,has_header:false,strategy:'merge'})});el.textContent=`SUCCESS · ${vals[0]} saved · ${r.rows_after_import} total rows`;await refreshMeta()}catch(e){el.textContent='FAILED: '+e.message}}
function render(){if(active==='DATA_IMPORT')renderImport();else if(active==='CONSENSUS_36')renderConsensus();else renderEngine()}init();
</script></body></html>'''

def evaluate(date_token:str):
    eval_started=datetime.utcnow().isoformat()+'Z'
    with DATA_LOCK:
        rows=ROWS[:]
    if date_token=='NEXT':
        history=rows; last=datetime.strptime(rows[-1]['date'],'%Y-%m-%d'); target_date=(last+timedelta(days=1)).strftime('%Y-%m-%d'); actual_row=None
    else:
        idx=next((i for i,r in enumerate(rows) if r['date']==date_token),None)
        if idx is None or idx==0:raise ValueError('Date not found or no prior history')
        history=rows[:idx];target_date=rows[idx]['date'];actual_row=rows[idx]
    cutoff=history[-1]['date'] if history else None;engines=[];house_rankings={h:{} for h in core.HOUSES}
    for name in ENGINE_ORDER:
        eng=ENGINE_MAP[name];houses={}
        for house in core.HOUSES:
            out=eng.rank(history,house,target_date);house_rankings[house][name]=out.ranking;actual=actual_row.get(house) if actual_row else None;rank=out.ranking.index(actual)+1 if actual and actual in out.ranking else None
            houses[house]={'ranking':out.ranking[:36],'actual':actual,'actual_rank':rank,'metrics':METRICS.get(house,{}).get(name),'meta':out.meta}
        engines.append({'name':name,'family':ENGINE_FAMILY[name],'description':ENGINE_DESCRIPTIONS.get(name,''),'houses':houses})
    consensus_houses={}
    for house in core.HOUSES:
        ranked,details=consensus36(house_rankings[house]);actual=actual_row.get(house) if actual_row else None;actual_rank=ranked.index(actual)+1 if actual else None;cm=CONS_METRICS.get(house,{})
        metrics={k:cm.get(k) for k in ('15','30','60','expanding')} if cm else None;consensus_houses[house]={'ranking':ranked[:36],'actual':actual,'actual_rank':actual_rank,'metrics':metrics,'details':details}
    for e in engines:
        audit_log('engines','engine_target_complete',target_date=target_date,source_cutoff=cutoff,engine=e['name'],family=e['family'],houses=list(e['houses'].keys()))
        for house,x in e['houses'].items():
            audit_log('predictions','engine_prediction',target_date=target_date,source_cutoff=cutoff,engine=e['name'],house=house,top36=x['ranking'],actual=x['actual'],actual_rank=x['actual_rank'])
    for house,x in consensus_houses.items():
        audit_log('consensus','consensus_prediction',target_date=target_date,source_cutoff=cutoff,house=house,top36=x['ranking'],actual=x['actual'],actual_rank=x['actual_rank'],weights=CONS_WEIGHTS)
    cutoff_ok=(cutoff is None or cutoff < target_date)
    audit_log('integrity','evaluation_cutoff_check',target_date=target_date,source_cutoff=cutoff,pass_check=cutoff_ok,date_token=date_token)
    audit_log('runtime','evaluation_complete',target_date=target_date,source_cutoff=cutoff,date_token=date_token,started_utc=eval_started,engine_count=len(engines))
    return {'target_date':target_date,'source_cutoff':cutoff,'engines':engines,'consensus':{'name':'CONSENSUS_36','weights':CONS_WEIGHTS,'houses':consensus_houses}}

class Handler(BaseHTTPRequestHandler):
    def _json(self,obj,status=200):
        raw=json.dumps(obj,ensure_ascii=False).encode();self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
    def _body_json(self):
        n=int(self.headers.get('Content-Length','0'));return json.loads(self.rfile.read(n).decode('utf-8')) if n else {}
    def do_GET(self):
        p=urlparse(self.path)
        audit_log('access','http_get',path=p.path,query=p.query,client=self.client_address[0] if self.client_address else None)
        if p.path in ('/','/index.html'):
            raw=HTML.encode();self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw);return
        if p.path=='/api/meta':
            with DATA_LOCK: rows=ROWS[:]
            self._json({'dates':[r['date'] for r in rows[1:]],'engines':[{'name':n,'family':ENGINE_FAMILY[n]} for n in ENGINE_ORDER],'row_count':len(rows),'first_date':rows[0]['date'] if rows else None,'last_date':rows[-1]['date'] if rows else None});return
        if p.path=='/api/evaluate':
            token=parse_qs(p.query).get('date',['NEXT'])[0]
            try:self._json(evaluate(token))
            except Exception as e:
                log_exception('evaluation_error',e,date_token=token,path=p.path);self._json({'error':str(e)},400)
            return
        if p.path=='/api/data.csv':
            raw=DATA_PATH.read_bytes();self.send_response(200);self.send_header('Content-Type','text/csv; charset=utf-8');self.send_header('Content-Disposition','attachment; filename="DHAPPA_current_data.csv"');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw);return
        self.send_error(404)
    def do_POST(self):
        p=urlparse(self.path)
        try:
            b=self._body_json()
            audit_log('access','http_post',path=p.path,client=self.client_address[0] if self.client_address else None,content_length=int(self.headers.get('Content-Length','0')),payload_redacted=True)
            if p.path=='/api/import/preview':self._json(import_preview(b.get('text',''),bool(b.get('has_header',True))));return
            if p.path=='/api/import/commit':self._json(commit_import(b.get('text',''),bool(b.get('has_header',True)),b.get('strategy','merge')));return
            self.send_error(404)
        except Exception as e:
            log_exception('http_post_error',e,path=p.path);self._json({'error':str(e)},400)
    def log_message(self,fmt,*args):pass

def main():
    host='127.0.0.1';port=int(os.environ.get('DHAPPA_PORT','8765'));print(f'DHAPPA Engine Lab + 36 Consensus + Bulk Import: http://{host}:{port}');print('Press Ctrl+C to stop.')
    audit_log('runtime','application_start',host=host,port=port,row_count=len(ROWS),first_date=ROWS[0]['date'] if ROWS else None,last_date=ROWS[-1]['date'] if ROWS else None,engine_count=len(ENGINE_ORDER),dataset_sha256=sha256_file(DATA_PATH) if DATA_PATH.exists() else None)
    audit_log('security','local_bind',host=host,port=port,network_exposure='loopback_only')
    if os.environ.get('DHAPPA_NO_BROWSER')!='1':
        try:webbrowser.open(f'http://{host}:{port}')
        except:pass
    ThreadingHTTPServer((host,port),Handler).serve_forever()
if __name__=='__main__':main()
