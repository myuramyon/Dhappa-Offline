# DHAPPA Dynamic Primary Engine v2.2 Report

Dataset: **240 rows**, 2025-12-13 → 2026-08-29

## V2.2 election architecture
Champion/challenger gating with asymmetric incumbent protection. STRONG/MODERATE/WEAK/FAILING incumbent tiers receive progressively lower replacement friction. Paired rank evidence and a Top-5 damage budget are retained, while failing incumbents may be replaced rapidly or yield `NO_QUALIFIED_PRIMARY` rather than being locked in.

## Temporal methodology
For each target (`t-1`), engines receive only history ending at the immediately preceding row (`t-2`). Rankings and election are frozen first. The target result is appended to performance profiles only after election.

## House-wise results

| House | Targets | Elected | Abstain | Coverage | Top5/elected | Top10/elected | Top21/elected | Top36/elected | MRR | Mean rank | Switches | Current |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| Deshawar | 188 | 171 | 17 | 90.96% | 7.6% | 11.7% | 24.56% | 41.52% | 0.0601 | 46.94 | 6 | HOT_RECENCY |
| Faridabad | 192 | 177 | 15 | 92.19% | 5.65% | 11.86% | 25.42% | 37.29% | 0.0544 | 47.97 | 9 | G_SQUARE_HARMONICS |
| Ghaziabad | 191 | 176 | 15 | 92.15% | 5.11% | 11.36% | 25.0% | 46.59% | 0.0476 | 48.05 | 8 | TRANSITION_MARKOV |
| Gali | 190 | 175 | 15 | 92.11% | 4.0% | 8.0% | 20.0% | 30.29% | 0.0417 | 52.34 | 10 | ECHO_7 |

## Interpretation
V2.2 is allowed to abstain and uses tier-dependent challenger proof rather than universal champion protection. Therefore conditional hit rates on elected targets must be read together with election coverage; lower coverage can inflate conditional metrics. The all-target Top-5 measure is retained in JSON to prevent selective-reporting bias. Random ranking references remain Top-5=5%, Top-10=10%, Top-21=21%, Top-36=36%.

## Integrity conclusion
V2.2 preserves prior-only election ordering while making champion protection asymmetric to avoid weak-incumbent lock-in. Election and route qualification are now performed entirely from previously completed targets, followed by immutable freeze and only then outcome evaluation.